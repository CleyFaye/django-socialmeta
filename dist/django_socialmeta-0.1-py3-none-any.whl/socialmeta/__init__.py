from .config import Config as SocialMetaConfig
